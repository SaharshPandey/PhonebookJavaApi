
package phonebook;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import javax.swing.*;


public class PhoneBook {

   //Hashtable ht=new Hashtable();
   
   PhoneBook()
    {
      /*ht.put("Saharsh","8449681651");
      ht.put("Fire","101");
      ht.put("Police","100");
      */
     JFrame jf=new JFrame("PhoneBook");
     JPanel jp=new JPanel();
     jp.setLayout(null);
     JTextField jtf=new JTextField();
    
     
     
     JButton jb1=new JButton("1");
     JButton jb2=new JButton("2");
     JButton jb3=new JButton("3");
     JButton jb4=new JButton("4");
     JButton jb5=new JButton("5");
     JButton jb6=new JButton("6");
     JButton jb7=new JButton("7");
     JButton jb8=new JButton("8");
     JButton jb9=new JButton("9"); 
     JButton jb0=new JButton("0");
     JButton jbstar=new JButton("*");
     JButton jbhash=new JButton("#"); 
     JButton jbcut=new JButton("-");
     JLabel jl=new JLabel("You On A Call...");
     JButton jbadd=new JButton("NEW CONTACT");
     JButton jbcall=new JButton("Call");
    // JButton jbcontact2=new JButton("Fire  101");
    // JButton jbcontact3=new JButton("Police  100");
    
     JComboBox jcb=new JComboBox();
    // ArrayList<String> arr = new ArrayList<String>();
     //JList jl=new JList();
     
     
     
     
     DefaultListModel<String> model = new DefaultListModel<>();
        

        JList<String> list = new JList<>(model);
        list.setCellRenderer(new DefaultListCellRenderer());
        list.setVisible(true);
        list.setBounds(0, 20, 130, 200);
   jb1.addActionListener(new ActionListener(){

         @Override
         public void actionPerformed(ActionEvent e) {
              model.clear();
           if(jtf.getText().equalsIgnoreCase("1"))
           {model.clear();
              model.addElement("Amit 9454337432");
        model.addElement("Bob 763437432");
        model.addElement("Clary 8999437432"); throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
         }
       
        
          }
        
     });
   
jb2.addActionListener(new ActionListener(){

         @Override
         public void actionPerformed(ActionEvent e) {
           model.clear();
           if(jtf.getText().equalsIgnoreCase("2"))
           {
             model.addElement("David 9454337432");
        model.addElement("Ela 763437432");
        model.addElement("Fury 8999437432"); throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
         }
            else if(jtf.getText().equalsIgnoreCase("12"))
           {model.clear();
              model.addElement("Bob 763437432");
               model.addElement("Clary 8999437432");
         }
         }
     });
jb3.addActionListener(new ActionListener(){

         @Override
         public void actionPerformed(ActionEvent e) {
              model.clear();
           if(jtf.getText().equalsIgnoreCase("3"))
           {
              model.addElement("Glorie 9454337432");
        model.addElement("Hemant 763437432");
        model.addElement("India 8999437432"); throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
         }
          else if(jtf.getText().equalsIgnoreCase("123"))
           {model.clear();
              
               model.addElement("Clary 8999437432");
         }}
     });
jb4.addActionListener(new ActionListener(){

         @Override
         public void actionPerformed(ActionEvent e) {
              model.clear();
           if(jtf.getText().equalsIgnoreCase("4"))
           {
              model.addElement("James 9454337432");
        model.addElement("Kunal 763437432");
        model.addElement("Lum 8999437432"); throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
         }}
     });
jb5.addActionListener(new ActionListener(){

         @Override
         public void actionPerformed(ActionEvent e) {
              model.clear();
           if(jtf.getText().equalsIgnoreCase("5"))
           {
              model.addElement("Mohit 9454337432");
        model.addElement("Nano 763437432");
        model.addElement("Oops 8999437432"); throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
         }}
     });

        jb6.addActionListener(new ActionListener(){

         @Override
         public void actionPerformed(ActionEvent e) {
              model.clear();
           if(jtf.getText().equalsIgnoreCase("6"))
           {              model.addElement("Peon 9454337432");
        model.addElement("Queen 763437432");
        model.addElement("Romeo 8999437432"); 
        model.addElement("Saharsh 8449681651");
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
         
         }}
     }); 
        jb7.addActionListener(new ActionListener(){

         @Override
         public void actionPerformed(ActionEvent e) {
              model.clear();
              if(jtf.getText().equalsIgnoreCase("7"))
              {
            model.addElement("Tom 9454337432");
        model.addElement("Umber 763437432");
        model.addElement("Vimi 8999437432"); throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
         }}
     });
        jb8.addActionListener(new ActionListener(){

         @Override
         public void actionPerformed(ActionEvent e) {
              model.clear();
           if(jtf.getText().equalsIgnoreCase("8"))
           {
              model.addElement("Wolf 9454337432");
        model.addElement("Xath 763437432");
        model.addElement("Yelle 8999437432"); 
        model.addElement("Zombie 8449681651");
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
         
         }}
     }); 
     
      
     //jcb.addItem("saharsh  8449681651");
     jcb.addItem("");
     jcb.addItem("Fire 101");
     jcb.addItem("Police 100");
     jcb.addItem("Ambulance 103");
     jcb.addItem("Instant Access Health 104");
   
  jcb.setBounds(150,20,190,30);   
   jtf.setBounds(150,90,140,50);
    jb1.setBounds(150,170,45,40);
     jb2.setBounds(220,170,45,40);
      jb3.setBounds(290,170,45,40);
       jb4.setBounds(150,240,45,40);
        jb5.setBounds(220,240,45,40);
         jb6.setBounds(290,240,45,40);
          jb7.setBounds(150,310,45,40);
           jb8.setBounds(220,310,45,40);
            jb9.setBounds(290,310,45,40);
             jb0.setBounds(220,380,45,40);
              jbstar.setBounds(150,380,45,40);
               jbhash.setBounds(290,380,45,40);
                jbcut.setBounds(300, 95, 35, 40);
                 jbadd.setBounds(470, 10, 150 ,30);
                  //jl.setBounds(500, 100, 150, 400);
                  jbcall.setBounds(210,440, 60, 40);
                   jl.setBounds(200,500,100,30);                  
   jp.add(jtf);  
    jp.add(jb0);
     jp.add(jb1);
      jp.add(jb2);
       jp.add(jb3);
        jp.add(jb4);
         jp.add(jb5);
          jp.add(jb6);
           jp.add(jb7);
            jp.add(jb8);
             jp.add(jb9);
              jp.add(jbstar);
               jp.add(jbhash);
                jp.add(jbcut);
                //jp.add(jbadd);
                   jp.add(jcb);
                    jp.add(list);
                      jp.add(jbcall);
                      //jl.add(b1);
                       //jl.add(b2);
                        jp.add(jl);
                        jl.setVisible(false);
    jb0.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {
             jtf.setText(jtf.getText().concat(jb0.getText())); }
     });
        
     jb1.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {
             jtf.setText(jtf.getText().concat(jb1.getText())); }
     });
     
      jb2.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {
             jtf.setText(jtf.getText().concat(jb2.getText())); }
     });
      
       jb3.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {
             jtf.setText(jtf.getText().concat(jb3.getText())); }
     });
       
        jb4.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {
             jtf.setText(jtf.getText().concat(jb4.getText())); }
     });
         jb5.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {
             jtf.setText(jtf.getText().concat(jb5.getText())); }
     });
          jb6.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {
             jtf.setText(jtf.getText().concat(jb6.getText())); }
     });
           jb7.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {
             jtf.setText(jtf.getText().concat(jb7.getText())); }
     });
            jb8.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {
             jtf.setText(jtf.getText().concat(jb8.getText())); }
     });
             jb9.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {
             jtf.setText(jtf.getText().concat(jb9.getText())); }
     });
              jbstar.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {
             jtf.setText(jtf.getText().concat(jbstar.getText())); }
     });
               jbhash.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {
             jtf.setText(jtf.getText().concat(jbhash.getText())); }
     });
        
        jbcut.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {
         if(jtf.getText().length()!=0)
        {
             jtf.setText(jtf.getText().substring(0, jtf.getText().length()-1)); 
         }}
     });
         jbcall.addActionListener(new ActionListener(){
      
      @Override
      public void actionPerformed(ActionEvent e)
      {
      jl.setVisible(true);
      
      
      }
      });
    jf.add(jp);
    jf.setBounds(300, 200,500,600);
    jf.setVisible(true);
    jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    
    }
    
   
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    PhoneBook pb=new PhoneBook();
        
        // TODO code application logic here
    }
    
}
